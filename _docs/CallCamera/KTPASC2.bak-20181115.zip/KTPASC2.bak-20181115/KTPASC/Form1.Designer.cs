﻿namespace KTPASC
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lalTeam = new System.Windows.Forms.Label();
            this.lalName = new System.Windows.Forms.Label();
            this.lalBrithday = new System.Windows.Forms.Label();
            this.lalSex = new System.Windows.Forms.Label();
            this.lalLia = new System.Windows.Forms.Label();
            this.lalAddr = new System.Windows.Forms.Label();
            this.lalNation = new System.Windows.Forms.Label();
            this.lalPhoneNum = new System.Windows.Forms.Label();
            this.radMan = new System.Windows.Forms.RadioButton();
            this.radWoman = new System.Windows.Forms.RadioButton();
            this.cboNation = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtLia = new System.Windows.Forms.TextBox();
            this.txtAddr = new System.Windows.Forms.TextBox();
            this.txtPhoneNum = new System.Windows.Forms.TextBox();
            this.txtIdCard = new System.Windows.Forms.TextBox();
            this.lalIdCard = new System.Windows.Forms.Label();
            this.lalValidity = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpBrithday = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNative = new System.Windows.Forms.TextBox();
            this.lalNative = new System.Windows.Forms.Label();
            this.lal1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtBankID = new System.Windows.Forms.TextBox();
            this.lalBankID = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lalBankName = new System.Windows.Forms.Label();
            this.cboBankName = new System.Windows.Forms.ComboBox();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.picBankCardBack = new AForge.Controls.PictureBox();
            this.picBankCardFront = new AForge.Controls.PictureBox();
            this.picFace = new AForge.Controls.PictureBox();
            this.videPlayer = new AForge.Controls.VideoSourcePlayer();
            this.lalFace = new System.Windows.Forms.Label();
            this.lalBankCardFront = new System.Windows.Forms.Label();
            this.lalBankCardBack = new System.Windows.Forms.Label();
            this.btnReadIDCard = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.cboTeam = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBankCardBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBankCardFront)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFace)).BeginInit();
            this.SuspendLayout();
            // 
            // lalTeam
            // 
            this.lalTeam.AutoSize = true;
            this.lalTeam.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lalTeam.Location = new System.Drawing.Point(764, 249);
            this.lalTeam.Name = "lalTeam";
            this.lalTeam.Size = new System.Drawing.Size(42, 21);
            this.lalTeam.TabIndex = 2;
            this.lalTeam.Text = "班组";
            this.lalTeam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lalName
            // 
            this.lalName.AutoSize = true;
            this.lalName.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalName.Location = new System.Drawing.Point(363, 38);
            this.lalName.Name = "lalName";
            this.lalName.Size = new System.Drawing.Size(39, 20);
            this.lalName.TabIndex = 4;
            this.lalName.Text = "姓名";
            // 
            // lalBrithday
            // 
            this.lalBrithday.AutoSize = true;
            this.lalBrithday.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalBrithday.Location = new System.Drawing.Point(767, 38);
            this.lalBrithday.Name = "lalBrithday";
            this.lalBrithday.Size = new System.Drawing.Size(39, 20);
            this.lalBrithday.TabIndex = 5;
            this.lalBrithday.Text = "生日";
            // 
            // lalSex
            // 
            this.lalSex.AutoSize = true;
            this.lalSex.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalSex.Location = new System.Drawing.Point(605, 38);
            this.lalSex.Name = "lalSex";
            this.lalSex.Size = new System.Drawing.Size(54, 20);
            this.lalSex.TabIndex = 6;
            this.lalSex.Text = "性别：";
            // 
            // lalLia
            // 
            this.lalLia.AutoSize = true;
            this.lalLia.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalLia.Location = new System.Drawing.Point(333, 126);
            this.lalLia.Name = "lalLia";
            this.lalLia.Size = new System.Drawing.Size(69, 20);
            this.lalLia.TabIndex = 7;
            this.lalLia.Text = "发证机关";
            // 
            // lalAddr
            // 
            this.lalAddr.AutoSize = true;
            this.lalAddr.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalAddr.Location = new System.Drawing.Point(363, 168);
            this.lalAddr.Name = "lalAddr";
            this.lalAddr.Size = new System.Drawing.Size(39, 20);
            this.lalAddr.TabIndex = 8;
            this.lalAddr.Text = "住址";
            // 
            // lalNation
            // 
            this.lalNation.AutoSize = true;
            this.lalNation.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalNation.Location = new System.Drawing.Point(767, 81);
            this.lalNation.Name = "lalNation";
            this.lalNation.Size = new System.Drawing.Size(39, 20);
            this.lalNation.TabIndex = 9;
            this.lalNation.Text = "民族";
            // 
            // lalPhoneNum
            // 
            this.lalPhoneNum.AutoSize = true;
            this.lalPhoneNum.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalPhoneNum.Location = new System.Drawing.Point(348, 249);
            this.lalPhoneNum.Name = "lalPhoneNum";
            this.lalPhoneNum.Size = new System.Drawing.Size(54, 20);
            this.lalPhoneNum.TabIndex = 10;
            this.lalPhoneNum.Text = "手机号";
            // 
            // radMan
            // 
            this.radMan.AutoSize = true;
            this.radMan.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.radMan.Location = new System.Drawing.Point(653, 36);
            this.radMan.Name = "radMan";
            this.radMan.Size = new System.Drawing.Size(42, 24);
            this.radMan.TabIndex = 1;
            this.radMan.TabStop = true;
            this.radMan.Text = "男";
            this.radMan.UseVisualStyleBackColor = true;
            this.radMan.CheckedChanged += new System.EventHandler(this.radMan_CheckedChanged);
            // 
            // radWoman
            // 
            this.radWoman.AutoSize = true;
            this.radWoman.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.radWoman.Location = new System.Drawing.Point(704, 36);
            this.radWoman.Name = "radWoman";
            this.radWoman.Size = new System.Drawing.Size(42, 24);
            this.radWoman.TabIndex = 2;
            this.radWoman.TabStop = true;
            this.radWoman.Text = "女";
            this.radWoman.UseVisualStyleBackColor = true;
            this.radWoman.CheckedChanged += new System.EventHandler(this.radWoman_CheckedChanged);
            // 
            // cboNation
            // 
            this.cboNation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNation.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.cboNation.FormattingEnabled = true;
            this.cboNation.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboNation.Location = new System.Drawing.Point(820, 79);
            this.cboNation.Name = "cboNation";
            this.cboNation.Size = new System.Drawing.Size(262, 28);
            this.cboNation.TabIndex = 9;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.txtName.Location = new System.Drawing.Point(413, 35);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(165, 27);
            this.txtName.TabIndex = 0;
            // 
            // txtLia
            // 
            this.txtLia.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.txtLia.Location = new System.Drawing.Point(413, 123);
            this.txtLia.Name = "txtLia";
            this.txtLia.Size = new System.Drawing.Size(333, 27);
            this.txtLia.TabIndex = 4;
            // 
            // txtAddr
            // 
            this.txtAddr.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.txtAddr.Location = new System.Drawing.Point(413, 166);
            this.txtAddr.Multiline = true;
            this.txtAddr.Name = "txtAddr";
            this.txtAddr.Size = new System.Drawing.Size(333, 63);
            this.txtAddr.TabIndex = 5;
            // 
            // txtPhoneNum
            // 
            this.txtPhoneNum.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.txtPhoneNum.Location = new System.Drawing.Point(413, 246);
            this.txtPhoneNum.Name = "txtPhoneNum";
            this.txtPhoneNum.Size = new System.Drawing.Size(333, 27);
            this.txtPhoneNum.TabIndex = 6;
            // 
            // txtIdCard
            // 
            this.txtIdCard.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.txtIdCard.Location = new System.Drawing.Point(413, 79);
            this.txtIdCard.Name = "txtIdCard";
            this.txtIdCard.Size = new System.Drawing.Size(333, 27);
            this.txtIdCard.TabIndex = 3;
            // 
            // lalIdCard
            // 
            this.lalIdCard.AutoSize = true;
            this.lalIdCard.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalIdCard.Location = new System.Drawing.Point(348, 82);
            this.lalIdCard.Name = "lalIdCard";
            this.lalIdCard.Size = new System.Drawing.Size(54, 20);
            this.lalIdCard.TabIndex = 21;
            this.lalIdCard.Text = "身份证";
            // 
            // lalValidity
            // 
            this.lalValidity.AutoSize = true;
            this.lalValidity.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalValidity.Location = new System.Drawing.Point(752, 126);
            this.lalValidity.Name = "lalValidity";
            this.lalValidity.Size = new System.Drawing.Size(54, 20);
            this.lalValidity.TabIndex = 23;
            this.lalValidity.Text = "有效期";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.CalendarFont = new System.Drawing.Font("微软雅黑", 11F);
            this.dtpStartDate.Location = new System.Drawing.Point(820, 126);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtpStartDate.Size = new System.Drawing.Size(113, 21);
            this.dtpStartDate.TabIndex = 10;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.CalendarFont = new System.Drawing.Font("微软雅黑", 11F);
            this.dtpEndDate.Location = new System.Drawing.Point(969, 125);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(113, 21);
            this.dtpEndDate.TabIndex = 11;
            // 
            // dtpBrithday
            // 
            this.dtpBrithday.CalendarFont = new System.Drawing.Font("微软雅黑", 11F);
            this.dtpBrithday.Location = new System.Drawing.Point(820, 38);
            this.dtpBrithday.Name = "dtpBrithday";
            this.dtpBrithday.Size = new System.Drawing.Size(127, 21);
            this.dtpBrithday.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(939, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 20);
            this.label1.TabIndex = 28;
            this.label1.Text = "至";
            // 
            // txtNative
            // 
            this.txtNative.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.txtNative.Location = new System.Drawing.Point(820, 166);
            this.txtNative.Multiline = true;
            this.txtNative.Name = "txtNative";
            this.txtNative.Size = new System.Drawing.Size(262, 63);
            this.txtNative.TabIndex = 12;
            // 
            // lalNative
            // 
            this.lalNative.AutoSize = true;
            this.lalNative.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalNative.Location = new System.Drawing.Point(767, 168);
            this.lalNative.Name = "lalNative";
            this.lalNative.Size = new System.Drawing.Size(39, 20);
            this.lalNative.TabIndex = 29;
            this.lalNative.Text = "籍贯";
            // 
            // lal1
            // 
            this.lal1.AutoSize = true;
            this.lal1.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lal1.ForeColor = System.Drawing.Color.Red;
            this.lal1.Location = new System.Drawing.Point(397, 38);
            this.lal1.Name = "lal1";
            this.lal1.Size = new System.Drawing.Size(16, 20);
            this.lal1.TabIndex = 31;
            this.lal1.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(397, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(397, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 20);
            this.label3.TabIndex = 32;
            this.label3.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(397, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 20);
            this.label4.TabIndex = 32;
            this.label4.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(801, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 20);
            this.label5.TabIndex = 32;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(801, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 20);
            this.label6.TabIndex = 32;
            this.label6.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(801, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 20);
            this.label7.TabIndex = 32;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(594, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(397, 289);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 20);
            this.label9.TabIndex = 36;
            this.label9.Text = "*";
            // 
            // txtBankID
            // 
            this.txtBankID.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.txtBankID.Location = new System.Drawing.Point(413, 286);
            this.txtBankID.Name = "txtBankID";
            this.txtBankID.Size = new System.Drawing.Size(333, 27);
            this.txtBankID.TabIndex = 7;
            // 
            // lalBankID
            // 
            this.lalBankID.AutoSize = true;
            this.lalBankID.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalBankID.Location = new System.Drawing.Point(348, 289);
            this.lalBankID.Name = "lalBankID";
            this.lalBankID.Size = new System.Drawing.Size(54, 20);
            this.lalBankID.TabIndex = 34;
            this.lalBankID.Text = "银行卡";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(801, 289);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "*";
            // 
            // lalBankName
            // 
            this.lalBankName.AutoSize = true;
            this.lalBankName.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalBankName.Location = new System.Drawing.Point(752, 289);
            this.lalBankName.Name = "lalBankName";
            this.lalBankName.Size = new System.Drawing.Size(54, 20);
            this.lalBankName.TabIndex = 37;
            this.lalBankName.Text = "所属行";
            // 
            // cboBankName
            // 
            this.cboBankName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBankName.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.cboBankName.FormattingEnabled = true;
            this.cboBankName.Location = new System.Drawing.Point(820, 285);
            this.cboBankName.Name = "cboBankName";
            this.cboBankName.Size = new System.Drawing.Size(262, 28);
            this.cboBankName.TabIndex = 13;
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(413, 6);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(75, 23);
            this.btnTest.TabIndex = 40;
            this.btnTest.Text = "测试";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(894, 489);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(186, 50);
            this.btnSubmit.TabIndex = 41;
            this.btnSubmit.Text = "提交";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(894, 545);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(186, 43);
            this.btnReset.TabIndex = 42;
            this.btnReset.Text = "重置";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // picBankCardBack
            // 
            this.picBankCardBack.BackgroundImage = global::KTPASC.Properties.Resources._250;
            this.picBankCardBack.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBankCardBack.Image = null;
            this.picBankCardBack.Location = new System.Drawing.Point(609, 338);
            this.picBankCardBack.Name = "picBankCardBack";
            this.picBankCardBack.Size = new System.Drawing.Size(250, 250);
            this.picBankCardBack.TabIndex = 43;
            this.picBankCardBack.TabStop = false;
            this.picBankCardBack.Click += new System.EventHandler(this.picBankCardBack_DoubleClick);
            // 
            // picBankCardFront
            // 
            this.picBankCardFront.BackgroundImage = global::KTPASC.Properties.Resources._250;
            this.picBankCardFront.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBankCardFront.Image = null;
            this.picBankCardFront.Location = new System.Drawing.Point(313, 338);
            this.picBankCardFront.Name = "picBankCardFront";
            this.picBankCardFront.Size = new System.Drawing.Size(250, 250);
            this.picBankCardFront.TabIndex = 43;
            this.picBankCardFront.TabStop = false;
            this.picBankCardFront.Click += new System.EventHandler(this.picBankCardFront_DoubleClick);
            // 
            // picFace
            // 
            this.picFace.BackgroundImage = global::KTPASC.Properties.Resources._250;
            this.picFace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picFace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picFace.Image = null;
            this.picFace.Location = new System.Drawing.Point(17, 338);
            this.picFace.Name = "picFace";
            this.picFace.Size = new System.Drawing.Size(250, 250);
            this.picFace.TabIndex = 43;
            this.picFace.TabStop = false;
            this.picFace.Click += new System.EventHandler(this.picFace_DoubleClick);
            // 
            // videPlayer
            // 
            this.videPlayer.BackgroundImage = global::KTPASC.Properties.Resources._300;
            this.videPlayer.Location = new System.Drawing.Point(16, 13);
            this.videPlayer.Name = "videPlayer";
            this.videPlayer.Size = new System.Drawing.Size(300, 300);
            this.videPlayer.TabIndex = 12;
            this.videPlayer.Text = "videoSourcePlayer1";
            this.videPlayer.VideoSource = null;
            // 
            // lalFace
            // 
            this.lalFace.AutoSize = true;
            this.lalFace.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalFace.Location = new System.Drawing.Point(93, 590);
            this.lalFace.Name = "lalFace";
            this.lalFace.Size = new System.Drawing.Size(99, 20);
            this.lalFace.TabIndex = 44;
            this.lalFace.Text = "人脸采集图像";
            // 
            // lalBankCardFront
            // 
            this.lalBankCardFront.AutoSize = true;
            this.lalBankCardFront.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalBankCardFront.Location = new System.Drawing.Point(396, 590);
            this.lalBankCardFront.Name = "lalBankCardFront";
            this.lalBankCardFront.Size = new System.Drawing.Size(84, 20);
            this.lalBankCardFront.TabIndex = 45;
            this.lalBankCardFront.Text = "银行卡正面";
            // 
            // lalBankCardBack
            // 
            this.lalBankCardBack.AutoSize = true;
            this.lalBankCardBack.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.lalBankCardBack.Location = new System.Drawing.Point(692, 589);
            this.lalBankCardBack.Name = "lalBankCardBack";
            this.lalBankCardBack.Size = new System.Drawing.Size(84, 20);
            this.lalBankCardBack.TabIndex = 46;
            this.lalBankCardBack.Text = "银行卡背面";
            // 
            // btnReadIDCard
            // 
            this.btnReadIDCard.Location = new System.Drawing.Point(894, 338);
            this.btnReadIDCard.Name = "btnReadIDCard";
            this.btnReadIDCard.Size = new System.Drawing.Size(186, 130);
            this.btnReadIDCard.TabIndex = 47;
            this.btnReadIDCard.Text = "读取身份证";
            this.btnReadIDCard.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(800, 249);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 20);
            this.label11.TabIndex = 48;
            this.label11.Text = "*";
            // 
            // cboTeam
            // 
            this.cboTeam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTeam.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.cboTeam.FormattingEnabled = true;
            this.cboTeam.Location = new System.Drawing.Point(820, 245);
            this.cboTeam.Name = "cboTeam";
            this.cboTeam.Size = new System.Drawing.Size(262, 28);
            this.cboTeam.TabIndex = 49;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1089, 617);
            this.Controls.Add(this.cboTeam);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnReadIDCard);
            this.Controls.Add(this.lalBankCardBack);
            this.Controls.Add(this.lalBankCardFront);
            this.Controls.Add(this.lalFace);
            this.Controls.Add(this.picBankCardBack);
            this.Controls.Add(this.picBankCardFront);
            this.Controls.Add(this.picFace);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.cboBankName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lalBankName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtBankID);
            this.Controls.Add(this.lalBankID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lal1);
            this.Controls.Add(this.txtNative);
            this.Controls.Add(this.lalNative);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpBrithday);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.lalValidity);
            this.Controls.Add(this.txtIdCard);
            this.Controls.Add(this.lalIdCard);
            this.Controls.Add(this.txtPhoneNum);
            this.Controls.Add(this.txtAddr);
            this.Controls.Add(this.txtLia);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.cboNation);
            this.Controls.Add(this.radWoman);
            this.Controls.Add(this.radMan);
            this.Controls.Add(this.videPlayer);
            this.Controls.Add(this.lalPhoneNum);
            this.Controls.Add(this.lalNation);
            this.Controls.Add(this.lalAddr);
            this.Controls.Add(this.lalLia);
            this.Controls.Add(this.lalSex);
            this.Controls.Add(this.lalBrithday);
            this.Controls.Add(this.lalName);
            this.Controls.Add(this.lalTeam);
            this.Name = "Form1";
            this.Text = "建信开太平ASC桌面版";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBankCardBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBankCardFront)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFace)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lalTeam;
        private System.Windows.Forms.Label lalName;
        private System.Windows.Forms.Label lalBrithday;
        private System.Windows.Forms.Label lalSex;
        private System.Windows.Forms.Label lalLia;
        private System.Windows.Forms.Label lalAddr;
        private System.Windows.Forms.Label lalNation;
        private System.Windows.Forms.Label lalPhoneNum;
        private AForge.Controls.VideoSourcePlayer videPlayer;
        private System.Windows.Forms.RadioButton radMan;
        private System.Windows.Forms.RadioButton radWoman;
        private System.Windows.Forms.ComboBox cboNation;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtLia;
        private System.Windows.Forms.TextBox txtAddr;
        private System.Windows.Forms.TextBox txtPhoneNum;
        private System.Windows.Forms.TextBox txtIdCard;
        private System.Windows.Forms.Label lalIdCard;
        private System.Windows.Forms.Label lalValidity;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.DateTimePicker dtpBrithday;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNative;
        private System.Windows.Forms.Label lalNative;
        private System.Windows.Forms.Label lal1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtBankID;
        private System.Windows.Forms.Label lalBankID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lalBankName;
        private System.Windows.Forms.ComboBox cboBankName;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnReset;
        private AForge.Controls.PictureBox picFace;
        private AForge.Controls.PictureBox picBankCardFront;
        private AForge.Controls.PictureBox picBankCardBack;
        private System.Windows.Forms.Label lalFace;
        private System.Windows.Forms.Label lalBankCardFront;
        private System.Windows.Forms.Label lalBankCardBack;
        private System.Windows.Forms.Button btnReadIDCard;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cboTeam;
    }
}


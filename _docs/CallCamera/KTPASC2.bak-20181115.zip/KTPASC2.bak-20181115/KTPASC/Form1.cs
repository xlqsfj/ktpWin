﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using AForge.Video.DirectShow;

namespace KTPASC
{
    public partial class Form1 : Form
    {
        private string addr; // 住址
        private long bankID; // 银行卡号
        private string bankName; // 所属银行
        private DateTime brithday; // 生日
        private DateTime endDate; // 有效日期：终止日期
        private long idCard; // 身份证号
        private string Lia; // 发证机关

        private string name; // 姓名
        private string nation; // 民族

        private readonly Dictionary<string, string> nationalDic = new Dictionary<string, string>();
        private string native; // 籍贯
        private long phoneNum; // 手机号
        private int sex; // 性别 男：1 女：2
        private DateTime startDate; // 有效日期：起始日期

        private string team; // 班组名称

        //创建视频驱动对象
        private FilterInfoCollection videoDevices;

        public Form1()
        {
            InitializeComponent();
        }

        // Form1 加载
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // 枚举所有视频输入设备
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices.Count == 0)
                {
                    throw new ApplicationException();
                }

                if (videoDevices.Count >= 1)
                {
                    // 开启摄像头
                    CameraConn(0);
                }


                //加载民族列表
                for (var i = 1; i <= 56; i++)
                {
                    nationalDic.Add(i + "", KtpTools.getNational(i + ""));
                }

                foreach (var item in nationalDic)
                {
                    cboNation.Items.Add(item.Value);
                }
                cboNation.SelectedIndex = 0;


                //加载班组列表
                cboTeam.Items.Add("木工班组");
                cboTeam.Items.Add("杂工班组");
                cboTeam.Items.Add("砼工班组");

                //加载银行列表
                cboBankName.Items.Add("建设银行");
                cboBankName.Items.Add("交通银行");
                cboBankName.Items.Add("工商银行");
            }
            catch (ApplicationException)
            {
                MessageBox.Show("未发现摄像头驱动,请检查是否连接摄像头", "建信开太平ASC提示:");
                videoDevices = null;
                Application.Exit();
            }
        }

        //连接摄像头
        private void CameraConn(int index)
        {
            try
            {
                //videoDevices[1]使用默认摄像头
                var videoSource = new VideoCaptureDevice(videoDevices[index].MonikerString);
                //重新绘制摄像头画面大小300*300
                videoSource.DesiredFrameSize = new Size(300, 300);

                //设置摄像头获取每秒帧数
                videoSource.DesiredFrameRate = 30;

                videPlayer.VideoSource = videoSource;
                videPlayer.Start();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("未发现摄像头驱动", "错误信息");
                videoDevices = null;
                Application.Exit();
            }
        }

        /// <summary>
        ///     保存图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Image img = new Bitmap(videPlayer.Width, videPlayer.Height);
            videPlayer.DrawToBitmap((Bitmap) img, new Rectangle(0, 0, videPlayer.Width, videPlayer.Height));
            img.Save(@"E:/a.bmp", ImageFormat.Bmp);
        }

        private void radMan_CheckedChanged(object sender, EventArgs e)
        {
            //设置sex为男
            sex = 1;
        }

        private void radWoman_CheckedChanged(object sender, EventArgs e)
        {
            //设置sex为女
            sex = 2;
        }

        //测试按钮
        private void btnTest_Click(object sender, EventArgs e)
        {
            txtName.Text = "周聪";
            radMan.Checked = true;
            txtIdCard.Text = "6543241995909230013";
            txtLia.Text = "新疆维吾尔族自治区";
            txtAddr.Text = "新疆哈巴河县阿克齐镇民主中路2区2号";
            txtPhoneNum.Text = "18588591324";
            txtBankID.Text = "6222620810005838368";
            dtpBrithday.Value = Convert.ToDateTime("1995/09/23");
            cboNation.SelectedItem = "汉族";
            dtpStartDate.Value = Convert.ToDateTime("2017/09/23");
            dtpEndDate.Value = Convert.ToDateTime("2019/09/23");
            txtNative.Text = "湖南";
            cboBankName.Text = "交通银行";
        }

        //人脸图片双击事件
        private void picFace_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                //MessageBox.Show("XXX");
                var face = new Bitmap(videPlayer.Width, videPlayer.Height);
                videPlayer.DrawToBitmap(face, new Rectangle(0, 0, videPlayer.Width, videPlayer.Height));
                //保存图片
                //face.Save(@"H:/测试图片/face.jpg", ImageFormat.Jpeg);
                //绘制图形到窗口
                picFace.Image = face;
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("获取图像失败，请检查摄像头是否正常", "错误提示:");
            }
            catch (ExternalException)
            {
                MessageBox.Show("磁盘空间已满或磁盘丢失", "错误提示:");
            }
        }

        //银行卡正面
        private void picBankCardFront_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                var bankCardFront = new Bitmap(videPlayer.Width, videPlayer.Height);
                videPlayer.DrawToBitmap(bankCardFront, new Rectangle(0, 0, videPlayer.Width, videPlayer.Height));
                //保存图片
                bankCardFront.Save(@"H:/测试图片/bankCardFront.jpg", ImageFormat.Jpeg);
                picBankCardFront.Image = bankCardFront;
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("获取图像失败，请检查摄像头是否正常", "错误提示:");
            }
            catch (ExternalException)
            {
                MessageBox.Show("磁盘空间已满或磁盘丢失", "错误提示:");
            }
        }

        // 银行卡背面
        private void picBankCardBack_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                var bankCardBack = new Bitmap(videPlayer.Width, videPlayer.Height);
                videPlayer.DrawToBitmap(bankCardBack, new Rectangle(0, 0, videPlayer.Width, videPlayer.Height));

                //保存图片
                bankCardBack.Save(@"H:/测试图片/bankCardBack.jpg", ImageFormat.Jpeg);
                //绘制图形到窗口
                picBankCardBack.Image = bankCardBack;
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("获取图像失败，请检查摄像头是否正常", "错误提示:");
            }
            catch (ExternalException)
            {
                MessageBox.Show("磁盘空间已满或磁盘丢失", "错误提示:");
            }
        }

        //提交
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtName.Text))
            {
                name = txtName.Text;
            }
            else
            {
                MessageBox.Show("姓名不能为空");
                return;
            }

            Lia = txtLia.Text;


            if (!string.IsNullOrEmpty(txtAddr.Text))
            {
                addr = txtAddr.Text;
            }
            else
            {
                MessageBox.Show("住址不能为空");
                return;
            }


            if (sex != 1 && sex != 2)
            {
                MessageBox.Show("请选择性别");
                return;
            }

            try
            {
                if (txtIdCard.Text.Length == 18 && KtpTools.CheckIDCard18(txtIdCard.Text))
                {
                    idCard = Convert.ToInt64(txtIdCard.Text);
                }
                else if (!KtpTools.CheckIDCard18(txtIdCard.Text))
                {
                    MessageBox.Show("请填写正确的身份证，请检查身份证号是否错误");
                    return;
                }
                else
                {
                    MessageBox.Show("身份证长度不为18位，请检查");
                    return;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("身份证信息错误，请检查");
                return;
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("身份证信息错误，请检查");
                return;
            }

            try
            {
                if (txtPhoneNum.Text.Length == 11)
                {
                    phoneNum = Convert.ToInt64(txtPhoneNum.Text);
                }
                else
                {
                    MessageBox.Show("请输入11位手机号，请检查");
                    return;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("请检查手机号是否正确");
                return;
            }

            try
            {
                nation = cboNation.SelectedItem.ToString();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("请选择正确的民族");
                return;
            }

            try
            {
                team = cboTeam.SelectedItem.ToString();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("请选择正确的班组");
                return;
            }

            try
            {
                bankName = cboBankName.SelectedItem.ToString();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("请选择正确的银行卡号");
                return;
            }

            try
            {
                bankID = Convert.ToInt64(txtBankID.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("请检查银行卡号是否正确");
                return;
            }

            brithday = dtpBrithday.Value.Date;
            startDate = dtpStartDate.Value.Date;
            endDate = dtpEndDate.Value.Date;
            native = txtNative.Text;

            MessageBox.Show("姓名:" + name + "\n" + sex + "\n" + idCard + "\n" + Lia + "\n" + addr + "\n" + phoneNum +
                            "\n" + bankID
                            + "\n" + brithday.ToShortDateString() + "\n" + nation + "\n" +
                            startDate.ToShortDateString() + "\n" + endDate.ToShortDateString() + "\n" + native + "\n" +
                            team
                            + "\n" + bankName
            );
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            radMan.Checked = false;
            radWoman.Checked = false;
            txtIdCard.Text = "";
            txtLia.Text = "";
            txtAddr.Text = "";
            txtPhoneNum.Text = "";
            txtBankID.Text = "";
            cboNation.SelectedIndex = -1;
            txtNative.Text = "";
            cboTeam.SelectedIndex = -1;
            cboBankName.SelectedIndex = -1;
        }
    }
}
﻿using System;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using KtpAcsMiddleware.ClientService.AuthenticationSyncs;
using KtpAcsMiddleware.ClientService.FileMaps;
using KtpAcsMiddleware.ClientService.TeamSyncs;
using KtpAcsMiddleware.ClientService.WorkerSyncs;
using KtpAcsMiddleware.Infrastructure.Utilities;

namespace KtpAcsMiddleware.WinForm
{
    public partial class KtpSync : Form
    {
        private bool _isRun;
        private bool _isStop;
        private Thread _uithread;
        private Thread _workthread;

        public KtpSync()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void TeamsSync_Load(object sender, EventArgs e)
        {
            _isRun = false;
        }

        private void TeamsSync_InputLanguageChanging(object sender, InputLanguageChangingEventArgs e)
        {
            _isStop = true;
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            if (_isRun)
            {
                MessageBox.Show(@"操作正在进行，需等待所有动作完成才能停止。");
                return;
            }
            StopService();
            //Application.Exit();
        }

        private void StartServiceButton_Click(object sender, EventArgs e)
        {
            _isStop = false;
            _uithread = new Thread(DisableControls) {IsBackground = true};
            _uithread.Start();

            _workthread = new Thread(StartService) {IsBackground = true};
            _workthread.Start();
        }

        private void StartService()
        {
            var exMessage = string.Empty;
            while (true)
            {
                try
                {
                    _isRun = true;
                    StopButton.Enabled = false;
                    var teamSyncService = new TeamSyncService();
                    var fileMapQiniuService = new FileMapQiniuService();
                    var workerSyncService = new WorkerSyncService();
                    var authenticationSyncService = new AuthenticationSyncService();

                    workerSyncService.RefreshIdentityCreditScore();
                    LogHelper.Info(@"更新工人身份证信用分完成......");
                    fileMapQiniuService.AddNewQiniuFiles();
                    LogHelper.Info(@"同步文件到七牛完成......");
                    teamSyncService.LoadTeams();
                    LogHelper.Info(@"从开太平同步班组完成......");
                    teamSyncService.AddTeams();
                    LogHelper.Info(@"添加班组到开太平完成......");
                    teamSyncService.EditTeams();
                    LogHelper.Info(@"编辑班组到开太平完成......");
                    workerSyncService.LoadWorkers();
                    LogHelper.Info(@"从开太平同步工人完成......");
                    workerSyncService.AddWorkers();
                    LogHelper.Info(@"添加(或编辑)工人同步完成......");
                    workerSyncService.DelWorkers();
                    LogHelper.Info(@"删除工人同步完成......");
                    authenticationSyncService.AddAuthentications();
                    LogHelper.Info(@"考勤信息同步完成......");
                    //teamSyncService.DeleteTeams();
                    //LogHelper.Info(@"删除班组同步完成......");
                    _isRun = false;

                    if (!_isStop)
                    {
                        StopButton.Enabled = true;
                        Thread.Sleep(ConfigHelper.ThreadSleepTimeout);
                    }
                    else
                    {
                        break;
                    }
                    //MessageBox.Show(@"同步完成");
                }
                catch (Exception ex)
                {
                    LogHelper.ExceptionLog(ex);
                    exMessage = $"{ex.Message}{ex.StackTrace.ToString(CultureInfo.InvariantCulture)}";
                    _isRun = false;
                    break;
                }
            }
            if (!string.IsNullOrEmpty(exMessage))
            {
                MessageBox.Show(string.Format("出现异常,{0}", exMessage));
            }
            StopService();
        }

        private void StopService()
        {
            _isStop = true;
            if (_uithread != null && _uithread.IsAlive)
            {
                _uithread.Abort();
            }
            EnabledControls();
            if (_workthread != null && _workthread.IsAlive)
            {
                _workthread.Abort();
            }
        }

        private void DisableControls()
        {
            Text = @"KtpAcsMiddleware数据同步-运行中...";
            StartServiceButton.Enabled = false;
        }

        private void EnabledControls()
        {
            Text = @"KtpAcsMiddleware数据同步";
            StartServiceButton.Enabled = true;
        }
    }
}
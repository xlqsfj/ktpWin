﻿namespace KtpAcsMiddleware.WinForm.Teams
{
    partial class TeamDetailed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.NameTxt = new System.Windows.Forms.TextBox();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.TeamIdLabel = new System.Windows.Forms.Label();
            this.WorkTypeIdsCb = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "名称";
            // 
            // NameTxt
            // 
            this.NameTxt.Location = new System.Drawing.Point(47, 43);
            this.NameTxt.Name = "NameTxt";
            this.NameTxt.Size = new System.Drawing.Size(193, 21);
            this.NameTxt.TabIndex = 1;
            // 
            // SaveBtn
            // 
            this.SaveBtn.Location = new System.Drawing.Point(246, 41);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(75, 23);
            this.SaveBtn.TabIndex = 2;
            this.SaveBtn.Text = "保存";
            this.SaveBtn.UseVisualStyleBackColor = true;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // TeamIdLabel
            // 
            this.TeamIdLabel.AutoSize = true;
            this.TeamIdLabel.Location = new System.Drawing.Point(45, 40);
            this.TeamIdLabel.Name = "TeamIdLabel";
            this.TeamIdLabel.Size = new System.Drawing.Size(0, 12);
            this.TeamIdLabel.TabIndex = 3;
            this.TeamIdLabel.Visible = false;
            // 
            // WorkTypeIdsCb
            // 
            this.WorkTypeIdsCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.WorkTypeIdsCb.FormattingEnabled = true;
            this.WorkTypeIdsCb.Location = new System.Drawing.Point(47, 16);
            this.WorkTypeIdsCb.Name = "WorkTypeIdsCb";
            this.WorkTypeIdsCb.Size = new System.Drawing.Size(193, 20);
            this.WorkTypeIdsCb.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "工种";
            // 
            // TeamDetailed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 72);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.WorkTypeIdsCb);
            this.Controls.Add(this.TeamIdLabel);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.NameTxt);
            this.Controls.Add(this.label1);
            this.Name = "TeamDetailed";
            this.Text = "班组信息";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NameTxt;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Label TeamIdLabel;
        private System.Windows.Forms.ComboBox WorkTypeIdsCb;
        private System.Windows.Forms.Label label2;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using KtpAcsMiddleware.AppService.Dto;
using KtpAcsMiddleware.ClientService;
using KtpAcsMiddleware.Domain.Data;
using KtpAcsMiddleware.Domain.Workers;

namespace KtpAcsMiddleware.WinForm.Teams
{
    public partial class TeamWorkerList : Form
    {
        private IList<Team> _teams;
        private IList<TeamWorkerGridDto> _teamWorkers;

        public TeamWorkerList()
        {
            InitializeComponent();
            BindTeams();
        }

        /// <summary>
        ///     班组选中项改变
        /// </summary>
        private void TeamsLb_SelectedIndexChanged(object sender, EventArgs e)
        {
            InitTeamsCmsItemsVisible();
            BindTeamWorkers();
        }

        /// <summary>
        ///     右键触发班组编辑
        /// </summary>
        private void TeamEditMenuItem_Click(object sender, EventArgs e)
        {
            var teamId = GetCurrentTeamId();
            if (teamId == null)
            {
                MessageBox.Show(@"没有选中的班组");
                return;
            }
            new TeamDetailed(teamId).ShowDialog();
            BindTeams();
        }

        /// <summary>
        ///     右键触发班组添加
        /// </summary>
        private void TeamAddMenuItem_Click(object sender, EventArgs e)
        {
            new TeamDetailed().ShowDialog();
            BindTeams();
        }

        /// <summary>
        ///     右键触发工人添加(班组右键)
        /// </summary>
        private void TeamWorkerAddMenuItem_Click(object sender, EventArgs e)
        {
            new TeamWorkerDetailed().ShowDialog();
            BindTeams();
        }

        /// <summary>
        ///     右键触发工人编辑
        /// </summary>
        private void WorkerEditMenuItem_Click(object sender, EventArgs e)
        {
            if (WorkersGrid.CurrentRow != null)
            {
                var currentRowIndex = WorkersGrid.CurrentRow.Index;
                var id = WorkersGrid.Rows[currentRowIndex].Cells[0].Value.ToString();
                new TeamWorkerDetailed(id).ShowDialog();
                BindTeamWorkers();
            }
            else
            {
                MessageBox.Show(@"没有选中的工人");
            }
        }

        /// <summary>
        ///     右键触发工人删除
        /// </summary>
        private void WorkerDelMenuItem_Click(object sender, EventArgs e)
        {
        }

        /// <summary>
        ///     右键触发工人添加
        /// </summary>
        private void WorkerAddMenuItem_Click(object sender, EventArgs e)
        {
            new TeamWorkerDetailed().ShowDialog();
            BindTeamWorkers();
        }

        /// <summary>
        ///     班组列表绑定
        /// </summary>
        private void BindTeams()
        {
            TeamsLb.Items.Clear();
            _teams = ClientFactory.TeamService.GetAll();
            if (_teams == null || _teams.Count == 0)
                return;
            foreach (var team in _teams)
                TeamsLb.Items.Add(team.Name);
            TeamsLb.SetSelected(0, true);
            BindTeamWorkers();
        }

        /// <summary>
        ///     工人列表绑定
        /// </summary>
        private void BindTeamWorkers()
        {
            var teamId = GetCurrentTeamId();
            if (teamId == null)
            {
                MessageBox.Show(@"没有选中任何班组");
                return;
            }
            _teamWorkers = ClientFactory.TeamWorkerService.Get(
                teamId, string.Empty, WorkerAuthenticationState.All);
            WorkersGrid.AutoGenerateColumns = false;
            WorkersGrid.DataSource = _teamWorkers;
        }

        /// <summary>
        ///     初始化班组列表的右键项目
        /// </summary>
        private void InitTeamsCmsItemsVisible()
        {
            if (TeamsLb.SelectedItem == null)
            {
                TeamsCms.Items[0].Visible = false;
                TeamsCms.Items[2].Visible = false;
            }
            else
            {
                TeamsCms.Items[0].Visible = true;
                TeamsCms.Items[2].Visible = true;
            }
        }

        private string GetCurrentTeamId()
        {
            if (TeamsLb.SelectedItem == null)
            {
                return null;
            }
            var teamName = TeamsLb.SelectedItem.ToString();
            var team = _teams.FirstOrDefault(i => i.Name == teamName);
            if (team == null)
            {
                return string.Empty;
            }
            return team.Id;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using AForge.Video.DirectShow;
using KtpAcsMiddleware.ClientService;
using KtpAcsMiddleware.Domain.Base;
using KtpAcsMiddleware.Domain.Data;
using KtpAcsMiddleware.Domain.Dto;
using KtpAcsMiddleware.Domain.Workers;
using KtpAcsMiddleware.Infrastructure.Utilities;

namespace KtpAcsMiddleware.WinForm.Teams
{
    public partial class TeamWorkerDetailed : Form
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
        public struct IDCardData
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string Name; //姓名   
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 6)]
            public string Sex;   //性别
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 20)]
            public string Nation; //名族
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 18)]
            public string Born; //出生日期
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 72)]
            public string Address; //住址
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 38)]
            public string IDCardNo; //身份证号
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string GrantDept; //发证机关
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 18)]
            public string UserLifeBegin; // 有效开始日期
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 18)]
            public string UserLifeEnd;  // 有效截止日期
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 38)]
            public string reserved; // 保留
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 255)]
            public string PhotoFileName; // 照片路径
        }
        /************************端口类API *************************/
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_GetCOMBaud", CharSet = CharSet.Ansi)]
        public static extern int Syn_GetCOMBaud(int iPort, ref uint puiBaudRate);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetCOMBaud", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetCOMBaud(int iPort, uint uiCurrBaud, uint uiSetBaud);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_OpenPort", CharSet = CharSet.Ansi)]
        public static extern int Syn_OpenPort(int iPort);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ClosePort", CharSet = CharSet.Ansi)]
        public static extern int Syn_ClosePort(int iPort);
        /**************************SAM类函数 **************************/
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetMaxRFByte", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetMaxRFByte(int iPort, byte ucByte, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ResetSAM", CharSet = CharSet.Ansi)]
        public static extern int Syn_ResetSAM(int iPort, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_GetSAMStatus", CharSet = CharSet.Ansi)]
        public static extern int Syn_GetSAMStatus(int iPort, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_GetSAMID", CharSet = CharSet.Ansi)]
        public static extern int Syn_GetSAMID(int iPort, ref byte pucSAMID, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_GetSAMIDToStr", CharSet = CharSet.Ansi)]
        public static extern int Syn_GetSAMIDToStr(int iPort, ref byte pcSAMID, int iIfOpen);
        /*************************身份证卡类函数 ***************************/
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_StartFindIDCard", CharSet = CharSet.Ansi)]
        public static extern int Syn_StartFindIDCard(int iPort, ref byte pucIIN, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SelectIDCard", CharSet = CharSet.Ansi)]
        public static extern int Syn_SelectIDCard(int iPort, ref byte pucSN, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ReadBaseMsg", CharSet = CharSet.Ansi)]
        public static extern int Syn_ReadBaseMsg(int iPort, ref byte pucCHMsg, ref uint puiCHMsgLen, ref byte pucPHMsg, ref uint puiPHMsgLen, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ReadBaseMsgToFile", CharSet = CharSet.Ansi)]
        public static extern int Syn_ReadBaseMsgToFile(int iPort, ref byte pcCHMsgFileName, ref uint puiCHMsgFileLen, ref byte pcPHMsgFileName, ref uint puiPHMsgFileLen, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ReadBaseFPMsg", CharSet = CharSet.Ansi)]
        public static extern int Syn_ReadBaseFPMsg(int iPort, ref byte pucCHMsg, ref uint puiCHMsgLen, ref byte pucPHMsg, ref uint puiPHMsgLen, ref byte pucFPMsg, ref uint puiFPMsgLen, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ReadBaseFPMsgToFile", CharSet = CharSet.Ansi)]
        public static extern int Syn_ReadBaseFPMsgToFile(int iPort, ref byte pcCHMsgFileName, ref uint puiCHMsgFileLen, ref byte pcPHMsgFileName, ref uint puiPHMsgFileLen, ref byte pcFPMsgFileName, ref uint puiFPMsgFileLen, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ReadNewAppMsg", CharSet = CharSet.Ansi)]
        public static extern int Syn_ReadNewAppMsg(int iPort, ref byte pucAppMsg, ref uint puiAppMsgLen, int iIfOpen);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_GetBmp", CharSet = CharSet.Ansi)]
        public static extern int Syn_GetBmp(int iPort, ref byte Wlt_File);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ReadMsg", CharSet = CharSet.Ansi)]
        public static extern int Syn_ReadMsg(int iPortID, int iIfOpen, ref IDCardData pIDCardData);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_ReadFPMsg", CharSet = CharSet.Ansi)]
        public static extern int Syn_ReadFPMsg(int iPortID, int iIfOpen, ref IDCardData pIDCardData, ref byte cFPhotoname);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_FindReader", CharSet = CharSet.Ansi)]
        public static extern int Syn_FindReader();
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_FindUSBReader", CharSet = CharSet.Ansi)]
        public static extern int Syn_FindUSBReader();
        /***********************设置附加功能函数 ************************/
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetPhotoPath", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetPhotoPath(int iOption, ref byte cPhotoPath);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetPhotoType", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetPhotoType(int iType);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetPhotoName", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetPhotoName(int iType);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetSexType", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetSexType(int iType);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetNationType", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetNationType(int iType);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetBornType", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetBornType(int iType);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetUserLifeBType", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetUserLifeBType(int iType);
        [DllImport("SynIDCardAPI.dll", EntryPoint = "Syn_SetUserLifeEType", CharSet = CharSet.Ansi)]
        public static extern int Syn_SetUserLifeEType(int iType, int iOption);

        int m_iPort; //端口号
        //以上是身份证读卡器调用

        private readonly string _msgCaption = "提示:";
        private string _facePicId;
        private string _identityBackPicId;
        private string _identityPicId;
        private TeamWorkerDto _teamWorker;

        public TeamWorkerDetailed()
        {
            InitializeComponent();
            BindNationsCb();
            BindTeamsCb();
            BindBankCardTypesCb();
            CameraConn();
            FindIdCardReader();
            _teamWorker = null;
            _facePicId = string.Empty;
            _identityPicId = string.Empty;
            _identityBackPicId = string.Empty;
        }

        public TeamWorkerDetailed(string id)
        {
            InitializeComponent();
            try
            {
                _teamWorker = ClientFactory.TeamWorkerService.Get(id);
                WorkerNameTxt.Text = _teamWorker.WorkerName;
                BirthdayDtp.Value = _teamWorker.Birthday;
                IdentityCodeTxt.Text = _teamWorker.IdentityCode;
                IssuingAuthorityTxt.Text = _teamWorker.IssuingAuthority;
                ActivateTimeDtp.Value = _teamWorker.ActivateTime;
                InvalidTimeDtp.Value = _teamWorker.InvalidTime;
                AddressNowTxt.Text = _teamWorker.AddressNow;
                AddressTxt.Text = _teamWorker.Address;
                MobileTxt.Text = _teamWorker.Mobile;
                BankCardCodeTxt.Text = _teamWorker.BankCardCode;

                if (_teamWorker.Sex == (int) WorkerSex.Man)
                {
                    ManRadio.Checked = true;
                }
                else
                {
                    LadyRadio.Checked = true;
                }
                BindNationsCb(_teamWorker.Nation);
                BindTeamsCb(_teamWorker.TeamId);
                BindBankCardTypesCb(_teamWorker.BankCardTypeId);

                BindPic(FacePic, _teamWorker.FacePicId);
                BindPic(IdentityPic, _teamWorker.IdentityPicId);
                BindPic(IdentityBackPic, _teamWorker.IdentityBackPicId);
                CameraConn();
                FindIdCardReader();
            }
            catch (Exception ex)
            {
                LogHelper.ExceptionLog(ex);
                MessageBox.Show($@"获取工人信息异常,exMessage={ex.Message}", _msgCaption);
            }
        }

        private void TeamWorkerDetailed_FormClosing(object sender, FormClosingEventArgs e)
        {
            AVidePlayer.SignalToStop();
            //AVidePlayer.Stop();
        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (_teamWorker == null)
                {
                    _teamWorker = new TeamWorkerDto();
                }
                _teamWorker.WorkerName = WorkerNameTxt.Text.Trim();
                _teamWorker.Birthday = BirthdayDtp.Value;
                _teamWorker.IdentityCode = IdentityCodeTxt.Text.Trim();
                _teamWorker.IssuingAuthority = IssuingAuthorityTxt.Text.Trim();
                _teamWorker.ActivateTime = ActivateTimeDtp.Value;
                _teamWorker.InvalidTime = InvalidTimeDtp.Value;
                _teamWorker.AddressNow = AddressNowTxt.Text.Trim();
                _teamWorker.Address = AddressTxt.Text.Trim();
                _teamWorker.Mobile = MobileTxt.Text.Trim();
                _teamWorker.BankCardCode = BankCardCodeTxt.Text.Trim();

                if (ManRadio.Checked)
                {
                    _teamWorker.Sex = (int) WorkerSex.Man;
                }
                else
                {
                    _teamWorker.Sex = (int) WorkerSex.Lady;
                }
                _teamWorker.Nation = int.Parse(NationCb.SelectedValue.ToString());
                _teamWorker.TeamId = TeamCb.SelectedValue.ToString();
                _teamWorker.BankCardTypeId = int.Parse(BankCardTypeCb.SelectedValue.ToString());
                if (!string.IsNullOrEmpty(_facePicId))
                {
                    _teamWorker.FacePicId = _facePicId;
                }
                if (!string.IsNullOrEmpty(_identityPicId))
                {
                    _teamWorker.IdentityPicId = _identityPicId;
                }
                if (!string.IsNullOrEmpty(_identityBackPicId))
                {
                    _teamWorker.IdentityPicId = _identityBackPicId;
                }
                if (string.IsNullOrEmpty(_teamWorker.Id))
                {
                    ClientFactory.WorkerService.Add(_teamWorker);
                }
                else
                {
                    ClientFactory.WorkerService.Change(_teamWorker, _teamWorker.Id);
                }
                MessageBox.Show(@"保存工人信息成功");
            }
            catch (Exception ex)
            {
                LogHelper.ExceptionLog(ex);
                MessageBox.Show($@"保存工人信息异常,exMessage={ex.Message}", _msgCaption);
            }
        }

        //连接摄像头(有多个时默认获取第0个)
        private void CameraConn()
        {
            //创建视频驱动对象
            FilterInfoCollection videoDevices = null;
            try
            {
                // 枚举所有视频输入设备
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (videoDevices.Count == 0)
                {
                    MessageBox.Show(@"未发现摄像头驱动,请检查是否连接摄像头", _msgCaption);
                    Application.Exit();
                    return;
                }
                //使用默认摄像头
                var videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);
                //重新绘制摄像头画面大小300*300
                videoSource.DesiredFrameSize = new Size(300, 300);
                //设置摄像头获取每秒帧数
                videoSource.DesiredFrameRate = 30;
                AVidePlayer.VideoSource = videoSource;
                AVidePlayer.Start();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show(@"未发现摄像头驱动", _msgCaption);
                Application.Exit();
            }
        }
        //查找读卡器
        private void FindIdCardReader() {
            string stmp;
            int i;
            i = Syn_FindUSBReader();
            m_iPort = i;
            if (i <= 0)
            { 
                stmp = Convert.ToString(System.DateTime.Now) + "  没有找到读卡器";
                MessageBox.Show(stmp, _msgCaption);
            }
        }


        private void BindNationsCb(int? selectedValue = null)
        {
            IList<DictionaryKeyValueDto> nations =
                EnumHelper.GetAllValueDescriptions(typeof(IdentityNation)).Where(i => i.Key != 0).ToList();
            NationCb.DataSource = nations;
            NationCb.DisplayMember = "Value";
            NationCb.ValueMember = "Key";
            if (selectedValue != null)
            {
                NationCb.SelectedValue = selectedValue;
            }
            else
            {
                NationCb.SelectedIndex = 0;
            }
        }

        private void BindTeamsCb(string selectedValue = null)
        {
            var teams = ClientFactory.TeamService.GetAll();
            TeamCb.DataSource = teams;
            TeamCb.DisplayMember = "Name";
            TeamCb.ValueMember = "Id";
            if (selectedValue != null)
            {
                TeamCb.SelectedValue = selectedValue;
            }
            else
            {
                TeamCb.SelectedIndex = 0;
            }
        }

        private void BindBankCardTypesCb(int? selectedValue = null)
        {
            IList<DictionaryKeyValueDto> nations =
                EnumHelper.GetAllValueDescriptions(typeof(BankCardType)).Where(i => i.Key != 0).ToList();
            BankCardTypeCb.DataSource = nations;
            BankCardTypeCb.DisplayMember = "Value";
            BankCardTypeCb.ValueMember = "Key";
            if (selectedValue != null)
            {
                BankCardTypeCb.SelectedValue = selectedValue;
            }
            else
            {
                BankCardTypeCb.SelectedIndex = 0;
            }
        }

        private void FacePic_Click(object sender, EventArgs e)
        {
            _facePicId = GetPic(FacePic);
        }

        private void IdentityPic_Click(object sender, EventArgs e)
        {
            _identityPicId = GetPic(IdentityPic);
        }

        private void IdentityBackPic_Click(object sender, EventArgs e)
        {
            _identityBackPicId = GetPic(IdentityBackPic);
        }

        private string GetPic(PictureBox pictureBox)
        {
            FileStream fileStream = null;
            try
            {
                var picBitmap = new Bitmap(AVidePlayer.Width, AVidePlayer.Height);
                AVidePlayer.DrawToBitmap(picBitmap, new Rectangle(0, 0, AVidePlayer.Width, AVidePlayer.Height));
                //保存图片==单机做法，若web端与此端不在同一机子则需要通过webservice获取流
                var physicalFileName = $"{ConfigHelper.NewGuid}.jpg";
                var physicalFullName = $"{ConfigHelper.CustomFilesDir}{physicalFileName}";
                //创建一个文件流
                fileStream = new FileStream(physicalFullName, FileMode.Create);
                var bytes = Bitmap2Bytes(picBitmap);
                fileStream.Write(bytes, 0, bytes.Length);
                fileStream.Close();
                var newFileMap = ClientFactory.FileMapService.Add(new FileMap
                {
                    FileName = physicalFileName,
                    PhysicalFileName = physicalFileName,
                    PhysicalFullName = physicalFullName,
                    Length = bytes.Length
                });
                //绘制图形到窗口
                pictureBox.Image = ResizeImage(picBitmap,250,250);
                //faceBitmap.Dispose();
                return newFileMap.Id;
            }
            catch (NullReferenceException)
            {
                MessageBox.Show(@"获取图像失败，请检查摄像头是否正常", _msgCaption);
                return string.Empty;
            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
        }

        private void BindPic(PictureBox pictureBox, string fileId)
        {
            if (string.IsNullOrEmpty(fileId))
            {
                return;
            }
            FileStream fileStream = null;
            try
            {
                var fileMap = FileMapDataService.Get(fileId);
                //单机做法，若web端与此端不在同一机子则需要通过webservice获取流
                fileStream = new FileStream($@"{ConfigHelper.CustomFilesDir}{fileMap.PhysicalFileName}", FileMode.Open);
                pictureBox.Image = new Bitmap(new Bitmap(fileStream));
                fileStream.Close();
            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
        }

        private byte[] Bitmap2Bytes(Bitmap bm)
        {
            var ms = new MemoryStream();
            bm.Save(ms, ImageFormat.Bmp);
            var bytes = ms.GetBuffer(); //byte[]   bytes=   ms.ToArray(); 这两句都可以
            ms.Close();
            return bytes;
        }



        //重置
        private void ResetBtn_Click(object sender, EventArgs e)
        {
            WorkerNameTxt.Text = "";
            IdentityCodeTxt.Text = "";
            IssuingAuthorityTxt.Text = "";
            AddressNowTxt.Text = "";
            AddressTxt.Text = "";
            MobileTxt.Text = "";
            BankCardCodeTxt.Text = "";
            FacePic.Image = null;
            IdentityPic.Image = null;
            IdentityBackPic.Image = null;
        }



        //图片缩放 可以放到工具类里面- 0 -
        public static Bitmap ResizeImage(Bitmap bmp, int newW, int newH)
        {
            try
            {
                Bitmap b = new Bitmap(newW, newH);
                Graphics g = Graphics.FromImage(b);
                // 插值算法的质量
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(bmp, new Rectangle(0, 0, newW, newH), new Rectangle(0, 0, bmp.Width, bmp.Height), GraphicsUnit.Pixel);
                g.Dispose();
                return b;
            }
            catch
            {
                return null;
            }
        }

        private void IdentityCardReaderBtn_Click(object sender, EventArgs e)
        {
            IDCardData CardMsg = new IDCardData();
            int nRet, nPort, iPhotoType;
            string stmp;
            byte[] cPath = new byte[255];
            byte[] pucIIN = new byte[4];
            byte[] pucSN = new byte[8];
            nPort = m_iPort;
            if (IdentityHeadPic.Image != null)
            {
                IdentityHeadPic.Image.Dispose();
                IdentityHeadPic.Image = null;
            }
            //保存在当前路径下的
            cPath = Encoding.UTF8.GetBytes(System.Windows.Forms.Application.StartupPath + @"\_Files");
            Syn_SetPhotoPath(2, ref cPath[0]);  //设置照片路径	iOption 路径选项	0=C:	1=当前路径	2=指定路径
                                                //cPhotoPath	绝对路径,仅在iOption=2时有效
            iPhotoType = 0;
            Syn_SetPhotoType(1); //0 = bmp ,1 = jpg , 2 = base64 , 3 = WLT ,4 = 不生成
            Syn_SetPhotoName(3); // 生成照片文件名 0=tmp 1=姓名 2=身份证号 3=姓名_身份证号 

            Syn_SetSexType(1);  // 0=卡中存储的数据	1=解释之后的数据,男、女、未知
            Syn_SetNationType(0);// 0=卡中存储的数据	1=解释之后的数据 2=解释之后加"族"
            Syn_SetBornType(3);         // 0=YYYYMMDD,1=YYYY年MM月DD日,2=YYYY.MM.DD,3=YYYY-MM-DD,4=YYYY/MM/DD
            Syn_SetUserLifeBType(3);    // 0=YYYYMMDD,1=YYYY年MM月DD日,2=YYYY.MM.DD,3=YYYY-MM-DD,4=YYYY/MM/DD
            Syn_SetUserLifeEType(3, 1); // 0=YYYYMMDD(不转换),1=YYYY年MM月DD日,2=YYYY.MM.DD,3=YYYY-MM-DD,4=YYYY/MM/DD,
                                        // 0=长期 不转换,	1=长期转换为 有效期开始+50年           
            if (Syn_OpenPort(nPort) == 0)
            {
                if (Syn_SetMaxRFByte(nPort, 80, 0) == 0)
                {
                    nRet = Syn_StartFindIDCard(nPort, ref pucIIN[0], 0);
                    nRet = Syn_SelectIDCard(nPort, ref pucSN[0], 0);
                    nRet = Syn_ReadMsg(nPort, 0, ref CardMsg);
                    if (nRet == 0)
                    {
                        //"  姓名:" + CardMsg.Name;
                        //"  性别:" + CardMsg.Sex;
                        //"  民族:" + CardMsg.Nation;
                        //"  出生日期:" + CardMsg.Born;
                        //"  地址:" + CardMsg.Address;
                        //"  身份证号:" + CardMsg.IDCardNo;
                        //"  发证机关:" + CardMsg.GrantDept;
                        //"  有效期开始:" + CardMsg.UserLifeBegin;
                        //"  有效期结束:" + CardMsg.UserLifeEnd;
                        //"  照片文件名:" + CardMsg.PhotoFileName;

                        switch (CardMsg.Sex)
                        {
                            case "男":
                                ManRadio.Checked = true;
                                break;
                            case "女":
                                LadyRadio.Checked = true;
                                break;
                            default:
                                MessageBox.Show(@"性别未知，默认选择男.", _msgCaption);
                                ManRadio.Checked = true;
                                break;
                        }

                        WorkerNameTxt.Text = CardMsg.Name.Trim();
                        BirthdayDtp.Value = Convert.ToDateTime(CardMsg.Born);
                        IdentityCodeTxt.Text = CardMsg.IDCardNo.Trim();
                        IssuingAuthorityTxt.Text = CardMsg.GrantDept.Trim();
                        ActivateTimeDtp.Value = Convert.ToDateTime(CardMsg.UserLifeBegin);
                        InvalidTimeDtp.Value = Convert.ToDateTime(CardMsg.UserLifeEnd);
                        AddressNowTxt.Text = CardMsg.Address.Trim();
                        NationCb.SelectedIndex = (Convert.ToInt32(CardMsg.Nation) - 1);
                        if (iPhotoType == 0 || iPhotoType == 1)
                        {
                            IdentityHeadPic.Image = Image.FromFile(CardMsg.PhotoFileName);
                        }
                    }
                    else
                    {
                        stmp = Convert.ToString(System.DateTime.Now) + "  读取身份证信息错误,确认身份证放置位置，如放置正确则身份证可能损坏";
                        MessageBox.Show(@stmp, _msgCaption);

                    }
                }
            }
            else
            {
                stmp = Convert.ToString(System.DateTime.Now) + "  打开端口失败,确认身份证阅读器是否正常连接.";
                MessageBox.Show(@stmp, _msgCaption);
            }
        }

    }
}
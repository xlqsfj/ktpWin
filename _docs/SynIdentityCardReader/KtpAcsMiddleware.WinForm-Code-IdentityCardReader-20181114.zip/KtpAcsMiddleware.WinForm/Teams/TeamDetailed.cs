﻿using System;
using System.Windows.Forms;
using KtpAcsMiddleware.ClientService;
using KtpAcsMiddleware.Domain.Data;

namespace KtpAcsMiddleware.WinForm.Teams
{
    public partial class TeamDetailed : Form
    {
        public TeamDetailed()
        {
            InitializeComponent();
            BindWorkTypeIdsCb("");
        }

        public TeamDetailed(string id)
        {
            InitializeComponent();

            var team = ClientFactory.TeamService.Get(id);
            TeamIdLabel.Text = team.Id;
            NameTxt.Text = team.Name;

            BindWorkTypeIdsCb(team.WorkTypeId);
        }

        private void BindWorkTypeIdsCb(string selectedValue)
        {
            var workTypes = ClientFactory.TeamService.GetAllWorkTypes();
            workTypes.Add(new TeamWorkType {Id = string.Empty, Name = "选择"});
            WorkTypeIdsCb.DataSource = workTypes;
            WorkTypeIdsCb.DisplayMember = "Name";
            WorkTypeIdsCb.ValueMember = "Id";
            WorkTypeIdsCb.SelectedValue = selectedValue;
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (WorkTypeIdsCb.SelectedValue == null || WorkTypeIdsCb.SelectedValue.ToString() == string.Empty)
            {
                MessageBox.Show(@"工种必需选择");
                return;
            }
            if (string.IsNullOrEmpty(NameTxt.Text))
            {
                MessageBox.Show(@"班组名称不能为空");
                return;
            }
            var name = NameTxt.Text.Trim();
            var id = TeamIdLabel.Text;
            var team = new Team {Id = id, Name = name, WorkTypeId = WorkTypeIdsCb.SelectedValue.ToString()};
            if (ClientFactory.TeamService.Any(name, id))
            {
                MessageBox.Show(@"班组名称不能重复");
                return;
            }
            if (!string.IsNullOrEmpty(id))
            {
                ClientFactory.TeamService.Change(team, id);
            }
            else
            {
                ClientFactory.TeamService.Add(team);
            }
            Hide();
        }
    }
}
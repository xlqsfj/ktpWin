﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using AForge.Video.DirectShow;
using KtpAcsMiddleware.ClientService;
using KtpAcsMiddleware.Domain.Base;
using KtpAcsMiddleware.Domain.Data;
using KtpAcsMiddleware.Domain.Dto;
using KtpAcsMiddleware.Domain.Workers;
using KtpAcsMiddleware.Infrastructure.Utilities;

namespace KtpAcsMiddleware.WinForm.Teams
{
    public partial class TeamWorkerDetailed : Form
    {
        private readonly string _msgCaption = "提示:";
        private string _facePicId;
        private string _identityBackPicId;
        private string _identityPicId;
        private TeamWorkerDto _teamWorker;

        public TeamWorkerDetailed()
        {
            InitializeComponent();
            BindNationsCb();
            BindTeamsCb();
            BindBankCardTypesCb();
            CameraConn();
            _teamWorker = null;
            _facePicId = string.Empty;
            _identityPicId = string.Empty;
            _identityBackPicId = string.Empty;
        }

        public TeamWorkerDetailed(string id)
        {
            InitializeComponent();
            try
            {
                _teamWorker = ClientFactory.TeamWorkerService.Get(id);
                WorkerNameTxt.Text = _teamWorker.WorkerName;
                BirthdayDtp.Value = _teamWorker.Birthday;
                IdentityCodeTxt.Text = _teamWorker.IdentityCode;
                IssuingAuthorityTxt.Text = _teamWorker.IssuingAuthority;
                ActivateTimeDtp.Value = _teamWorker.ActivateTime;
                InvalidTimeDtp.Value = _teamWorker.InvalidTime;
                AddressNowTxt.Text = _teamWorker.AddressNow;
                AddressTxt.Text = _teamWorker.Address;
                MobileTxt.Text = _teamWorker.Mobile;
                BankCardCodeTxt.Text = _teamWorker.BankCardCode;

                if (_teamWorker.Sex == (int) WorkerSex.Man)
                {
                    ManRadio.Checked = true;
                }
                else
                {
                    LadyRadio.Checked = true;
                }
                BindNationsCb(_teamWorker.Nation);
                BindTeamsCb(_teamWorker.TeamId);
                BindBankCardTypesCb(_teamWorker.BankCardTypeId);

                BindPic(FacePic, _teamWorker.FacePicId);
                BindPic(IdentityPic, _teamWorker.IdentityPicId);
                BindPic(IdentityBackPic, _teamWorker.IdentityBackPicId);
                CameraConn();
            }
            catch (Exception ex)
            {
                LogHelper.ExceptionLog(ex);
                MessageBox.Show($@"获取工人信息异常,exMessage={ex.Message}", _msgCaption);
            }
        }

        private void TeamWorkerDetailed_FormClosing(object sender, FormClosingEventArgs e)
        {
            AVidePlayer.SignalToStop();
            //AVidePlayer.Stop();
        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (_teamWorker == null)
                {
                    _teamWorker = new TeamWorkerDto();
                }
                _teamWorker.WorkerName = WorkerNameTxt.Text.Trim();
                _teamWorker.Birthday = BirthdayDtp.Value;
                _teamWorker.IdentityCode = IdentityCodeTxt.Text.Trim();
                _teamWorker.IssuingAuthority = IssuingAuthorityTxt.Text.Trim();
                _teamWorker.ActivateTime = ActivateTimeDtp.Value;
                _teamWorker.InvalidTime = InvalidTimeDtp.Value;
                _teamWorker.AddressNow = AddressNowTxt.Text.Trim();
                _teamWorker.Address = AddressTxt.Text.Trim();
                _teamWorker.Mobile = MobileTxt.Text.Trim();
                _teamWorker.BankCardCode = BankCardCodeTxt.Text.Trim();

                if (ManRadio.Checked)
                {
                    _teamWorker.Sex = (int) WorkerSex.Man;
                }
                else
                {
                    _teamWorker.Sex = (int) WorkerSex.Lady;
                }
                _teamWorker.Nation = int.Parse(NationCb.SelectedValue.ToString());
                _teamWorker.TeamId = TeamCb.SelectedValue.ToString();
                _teamWorker.BankCardTypeId = int.Parse(BankCardTypeCb.SelectedValue.ToString());
                if (!string.IsNullOrEmpty(_facePicId))
                {
                    _teamWorker.FacePicId = _facePicId;
                }
                if (!string.IsNullOrEmpty(_identityPicId))
                {
                    _teamWorker.IdentityPicId = _identityPicId;
                }
                if (!string.IsNullOrEmpty(_identityBackPicId))
                {
                    _teamWorker.IdentityPicId = _identityBackPicId;
                }
                if (string.IsNullOrEmpty(_teamWorker.Id))
                {
                    ClientFactory.WorkerService.Add(_teamWorker);
                }
                else
                {
                    ClientFactory.WorkerService.Change(_teamWorker, _teamWorker.Id);
                }
                MessageBox.Show(@"保存工人信息成功");
            }
            catch (Exception ex)
            {
                LogHelper.ExceptionLog(ex);
                MessageBox.Show($@"保存工人信息异常,exMessage={ex.Message}", _msgCaption);
            }
        }

        //连接摄像头(有多个时默认获取第0个)
        private void CameraConn()
        {
            //创建视频驱动对象
            FilterInfoCollection videoDevices = null;
            try
            {
                // 枚举所有视频输入设备
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (videoDevices.Count == 0)
                {
                    MessageBox.Show(@"未发现摄像头驱动,请检查是否连接摄像头", _msgCaption);
                    Application.Exit();
                    return;
                }
                //使用默认摄像头
                var videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);
                //重新绘制摄像头画面大小300*300
                videoSource.DesiredFrameSize = new Size(300, 300);
                //设置摄像头获取每秒帧数
                videoSource.DesiredFrameRate = 30;
                AVidePlayer.VideoSource = videoSource;
                AVidePlayer.Start();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show(@"未发现摄像头驱动", _msgCaption);
                Application.Exit();
            }
        }

        private void BindNationsCb(int? selectedValue = null)
        {
            IList<DictionaryKeyValueDto> nations =
                EnumHelper.GetAllValueDescriptions(typeof(IdentityNation)).Where(i => i.Key != 0).ToList();
            NationCb.DataSource = nations;
            NationCb.DisplayMember = "Value";
            NationCb.ValueMember = "Key";
            if (selectedValue != null)
            {
                NationCb.SelectedValue = selectedValue;
            }
            else
            {
                NationCb.SelectedIndex = 0;
            }
        }

        private void BindTeamsCb(string selectedValue = null)
        {
            var teams = ClientFactory.TeamService.GetAll();
            TeamCb.DataSource = teams;
            TeamCb.DisplayMember = "Name";
            TeamCb.ValueMember = "Id";
            if (selectedValue != null)
            {
                TeamCb.SelectedValue = selectedValue;
            }
            else
            {
                TeamCb.SelectedIndex = 0;
            }
        }

        private void BindBankCardTypesCb(int? selectedValue = null)
        {
            IList<DictionaryKeyValueDto> nations =
                EnumHelper.GetAllValueDescriptions(typeof(BankCardType)).Where(i => i.Key != 0).ToList();
            BankCardTypeCb.DataSource = nations;
            BankCardTypeCb.DisplayMember = "Value";
            BankCardTypeCb.ValueMember = "Key";
            if (selectedValue != null)
            {
                BankCardTypeCb.SelectedValue = selectedValue;
            }
            else
            {
                BankCardTypeCb.SelectedIndex = 0;
            }
        }

        private void FacePic_Click(object sender, EventArgs e)
        {
            _facePicId = GetPic(FacePic);
        }

        private void IdentityPic_Click(object sender, EventArgs e)
        {
            _identityPicId = GetPic(IdentityPic);
        }

        private void IdentityBackPic_Click(object sender, EventArgs e)
        {
            _identityBackPicId = GetPic(IdentityBackPic);
        }

        private string GetPic(PictureBox pictureBox)
        {
            FileStream fileStream = null;
            try
            {
                var picBitmap = new Bitmap(AVidePlayer.Width, AVidePlayer.Height);
                AVidePlayer.DrawToBitmap(picBitmap, new Rectangle(0, 0, AVidePlayer.Width, AVidePlayer.Height));
                //保存图片==单机做法，若web端与此端不在同一机子则需要通过webservice获取流
                var physicalFileName = $"{ConfigHelper.NewGuid}.jpg";
                var physicalFullName = $"{ConfigHelper.CustomFilesDir}{physicalFileName}";
                //创建一个文件流
                fileStream = new FileStream(physicalFullName, FileMode.Create);
                var bytes = Bitmap2Bytes(picBitmap);
                fileStream.Write(bytes, 0, bytes.Length);
                fileStream.Close();
                var newFileMap = ClientFactory.FileMapService.Add(new FileMap
                {
                    FileName = physicalFileName,
                    PhysicalFileName = physicalFileName,
                    PhysicalFullName = physicalFullName,
                    Length = bytes.Length
                });
                //绘制图形到窗口
                pictureBox.Image = picBitmap;
                //faceBitmap.Dispose();
                return newFileMap.Id;
            }
            catch (NullReferenceException)
            {
                MessageBox.Show(@"获取图像失败，请检查摄像头是否正常", _msgCaption);
                return string.Empty;
            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
        }

        private void BindPic(PictureBox pictureBox, string fileId)
        {
            if (string.IsNullOrEmpty(fileId))
            {
                return;
            }
            FileStream fileStream = null;
            try
            {
                var fileMap = FileMapDataService.Get(fileId);
                //单机做法，若web端与此端不在同一机子则需要通过webservice获取流
                fileStream = new FileStream($@"{ConfigHelper.CustomFilesDir}{fileMap.PhysicalFileName}", FileMode.Open);
                pictureBox.Image = new Bitmap(new Bitmap(fileStream));
                fileStream.Close();
            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
        }

        private byte[] Bitmap2Bytes(Bitmap bm)
        {
            var ms = new MemoryStream();
            bm.Save(ms, ImageFormat.Bmp);
            var bytes = ms.GetBuffer(); //byte[]   bytes=   ms.ToArray(); 这两句都可以
            ms.Close();
            return bytes;
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            WorkerNameTxt.Text = "";
            IdentityCodeTxt.Text = "";
            IssuingAuthorityTxt.Text = "";
            AddressNowTxt.Text = "";
            AddressTxt.Text = "";
            MobileTxt.Text = "";
            BankCardCodeTxt.Text = "";
            FacePic.Image = null;
            IdentityPic.Image = null;
            IdentityBackPic.Image = null;
        }




    }
}
﻿using System;
using System.Windows.Forms;
using KtpAcsMiddleware.ClientService;
using KtpAcsMiddleware.Infrastructure.Utilities;
using KtpAcsMiddleware.WinForm.Teams;

namespace KtpAcsMiddleware.WinForm
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            if (ConfigHelper.IsDebug)
            {
                UserNameTxt.Text = @"admin";
                PasswordTxt.Text = @"123456";
            }
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(UserNameTxt.Text))
            {
                MessageBox.Show(@"用户名不允许为空");
                return;
            }
            if (string.IsNullOrEmpty(PasswordTxt.Text))
            {
                MessageBox.Show(@"密码不允许为空");
                return;
            }
            var loginErroMsg = @"用户名或者密码错误";
            var user = ClientFactory.OrgUserService.GetByAccount(UserNameTxt.Text);
            if (user == null)
            {
                MessageBox.Show(loginErroMsg);
                return;
            }
            if (user.Password != CryptographicHelper.Hash(PasswordTxt.Text))
            {
                MessageBox.Show(loginErroMsg);
                return;
            }
            Hide();
            new TeamWorkerList().Show();
        }
    }
}